// Seed data converted from constants/data.ts
// Images are now stored as path strings for API responses

const CATEGORIES_SEED = [
    {
        name: 'Chairs',
        description: 'Modern and classic chairs for every room',
        image: '/images/categories/chairs.png',
    },
    {
        name: 'Tables',
        description: 'Dining, coffee, and side tables',
        image: '/images/categories/tables.png',
    },
    {
        name: 'Sofas',
        description: 'Comfortable sofas for your living room',
        image: '/images/categories/sofas.png',
    },
    {
        name: 'Hanging chairs',
        description: 'Swing and hammock chairs for relaxation',
        image: '/images/categories/hanging-chairs.png',
    },
    {
        name: 'Cabinets',
        description: 'Storage and display cabinets',
        image: '/images/categories/cabinets.png',
    },
    {
        name: 'Lamps',
        description: 'Floor, table, desk, and wall lamps',
        image: '/images/categories/lamps.png',
    },
    {
        name: 'Cupboards',
        description: 'Kitchen, bedroom, and storage cupboards',
        image: '/images/categories/cupboards.png',
    },
];

const PRODUCTS_SEED = [
    // ============ CHAIRS ============
    {
        productId: 'chair-1',
        name: 'Buddy Chair',
        description: 'The buddy chair with modern comfort and durable fabric.',
        category: 'Chairs',
        price: 102.25,
        oldPrice: 120.00,
        discount: 20,
        rating: 5.0,
        totalRatings: 25586,
        reviews: 430,
        dimensions: { height: '115 cm', width: '115 cm', depth: '115 cm', weight: '115 cm' },
        colors: ['#FFB800', '#2C5F8D', '#C4893B', '#1a2632'],
        image: '/images/products/screen3_img1.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img1.png' },
            { label: 'Back', image: '/images/products/screen3_img2.png' },
            { label: 'Left', image: '/images/products/screen3_img3.png' },
            { label: 'Right', image: '/images/products/screen3_img4.png' },
        ],
        ratingBreakdown: { 5: 90, 4: 75, 3: 50, 2: 25, 1: 10 },
    },
    {
        productId: 'chair-2',
        name: 'Wingback Chair',
        description: 'Elegant wingback design with premium upholstery.',
        category: 'Chairs',
        price: 89.99,
        oldPrice: 115.00,
        discount: 22,
        rating: 4.8,
        totalRatings: 18420,
        reviews: 312,
        dimensions: { height: '110 cm', width: '85 cm', depth: '90 cm', weight: '18 kg' },
        colors: ['#8B7355', '#2C5F8D', '#1a2632'],
        image: '/images/products/screen3_img2.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img2.png' },
            { label: 'Back', image: '/images/products/screen3_img1.png' },
            { label: 'Left', image: '/images/products/screen3_img3.png' },
            { label: 'Right', image: '/images/products/screen3_img5.png' },
        ],
        ratingBreakdown: { 5: 85, 4: 70, 3: 45, 2: 20, 1: 8 },
    },
    {
        productId: 'chair-3',
        name: 'Winston Chair',
        description: 'Classic Winston chair with timeless appeal.',
        category: 'Chairs',
        price: 76.50,
        oldPrice: 95.00,
        discount: 19,
        rating: 4.6,
        totalRatings: 12350,
        reviews: 245,
        dimensions: { height: '105 cm', width: '80 cm', depth: '85 cm', weight: '15 kg' },
        colors: ['#C4893B', '#FFB800', '#1a2632'],
        image: '/images/products/screen3_img3.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img3.png' },
            { label: 'Back', image: '/images/products/screen3_img1.png' },
            { label: 'Left', image: '/images/products/screen3_img2.png' },
            { label: 'Right', image: '/images/products/screen3_img6.png' },
        ],
        ratingBreakdown: { 5: 80, 4: 65, 3: 40, 2: 18, 1: 12 },
    },
    {
        productId: 'chair-4',
        name: 'Beige Chair',
        description: 'Soft beige fabric with ergonomic support.',
        category: 'Chairs',
        price: 68.00,
        oldPrice: 85.00,
        discount: 20,
        rating: 4.5,
        totalRatings: 9870,
        reviews: 198,
        dimensions: { height: '100 cm', width: '75 cm', depth: '80 cm', weight: '12 kg' },
        colors: ['#D4C4A8', '#2C5F8D', '#1a2632'],
        image: '/images/products/screen3_img4.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img4.png' },
            { label: 'Back', image: '/images/products/screen3_img1.png' },
            { label: 'Left', image: '/images/products/screen3_img2.png' },
            { label: 'Right', image: '/images/products/screen3_img3.png' },
        ],
        ratingBreakdown: { 5: 75, 4: 60, 3: 35, 2: 15, 1: 10 },
    },

    // ============ TABLES ============
    {
        productId: 'table-1',
        name: 'Modern Table',
        description: 'Sleek modern design for contemporary spaces.',
        category: 'Tables',
        price: 120,
        oldPrice: 150,
        discount: 20,
        rating: 4.5,
        totalRatings: 8500,
        reviews: 180,
        dimensions: { height: '75 cm', width: '160 cm', depth: '90 cm', weight: '35 kg' },
        colors: ['#8B7355', '#1a2632'],
        image: '/images/products/screen3_img7.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img7.png' },
            { label: 'Back', image: '/images/products/screen3_img8.png' },
            { label: 'Left', image: '/images/products/screen3_img9.png' },
            { label: 'Right', image: '/images/products/screen3_img10.png' },
        ],
        ratingBreakdown: { 5: 78, 4: 62, 3: 38, 2: 14, 1: 8 },
    },
    {
        productId: 'table-2',
        name: 'Dining Table',
        description: 'Family sized table for memorable dinners.',
        category: 'Tables',
        price: 200,
        oldPrice: 250,
        discount: 20,
        rating: 4.6,
        totalRatings: 12300,
        reviews: 245,
        dimensions: { height: '76 cm', width: '180 cm', depth: '100 cm', weight: '45 kg' },
        colors: ['#D4C4A8', '#1a2632'],
        image: '/images/products/screen3_img8.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img8.png' },
            { label: 'Back', image: '/images/products/screen3_img7.png' },
            { label: 'Left', image: '/images/products/screen3_img9.png' },
            { label: 'Right', image: '/images/products/screen3_img10.png' },
        ],
        ratingBreakdown: { 5: 82, 4: 65, 3: 40, 2: 12, 1: 6 },
    },
    {
        productId: 'table-3',
        name: 'Coffee Table',
        description: 'Minimalist coffee table for your living room.',
        category: 'Tables',
        price: 85,
        oldPrice: 110,
        discount: 23,
        rating: 4.7,
        totalRatings: 6800,
        reviews: 132,
        dimensions: { height: '45 cm', width: '120 cm', depth: '60 cm', weight: '18 kg' },
        colors: ['#C4893B', '#1a2632'],
        image: '/images/products/screen3_img9.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img9.png' },
            { label: 'Back', image: '/images/products/screen3_img7.png' },
            { label: 'Left', image: '/images/products/screen3_img8.png' },
            { label: 'Right', image: '/images/products/screen3_img10.png' },
        ],
        ratingBreakdown: { 5: 85, 4: 70, 3: 35, 2: 10, 1: 5 },
    },
    {
        productId: 'table-4',
        name: 'Side Table',
        description: 'Compact side table for tight spaces.',
        category: 'Tables',
        price: 45,
        oldPrice: 60,
        discount: 25,
        rating: 4.4,
        totalRatings: 4500,
        reviews: 98,
        dimensions: { height: '55 cm', width: '45 cm', depth: '45 cm', weight: '8 kg' },
        colors: ['#5D7EA0', '#1a2632'],
        image: '/images/products/screen3_img10.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img10.png' },
            { label: 'Back', image: '/images/products/screen3_img7.png' },
            { label: 'Left', image: '/images/products/screen3_img8.png' },
            { label: 'Right', image: '/images/products/screen3_img9.png' },
        ],
        ratingBreakdown: { 5: 72, 4: 58, 3: 32, 2: 18, 1: 10 },
    },

    // ============ SOFAS ============
    {
        productId: 'sofa-1',
        name: 'Comfort Sofa',
        description: 'Ultra soft cushions for maximum relaxation.',
        category: 'Sofas',
        price: 350,
        oldPrice: 450,
        discount: 22,
        rating: 4.8,
        totalRatings: 15600,
        reviews: 320,
        dimensions: { height: '85 cm', width: '220 cm', depth: '95 cm', weight: '65 kg' },
        colors: ['#8B7355', '#2C5F8D', '#1a2632'],
        image: '/images/products/screen3_img11.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img11.png' },
            { label: 'Back', image: '/images/products/screen3_img12.png' },
            { label: 'Left', image: '/images/products/screen3_img13.png' },
            { label: 'Right', image: '/images/products/screen3_img14.png' },
        ],
        ratingBreakdown: { 5: 88, 4: 72, 3: 42, 2: 15, 1: 5 },
    },
    {
        productId: 'sofa-2',
        name: 'Modern Sofa',
        description: 'Contemporary design with clean lines.',
        category: 'Sofas',
        price: 400,
        oldPrice: 500,
        discount: 20,
        rating: 4.7,
        totalRatings: 12800,
        reviews: 275,
        dimensions: { height: '82 cm', width: '240 cm', depth: '100 cm', weight: '72 kg' },
        colors: ['#C4893B', '#1a2632'],
        image: '/images/products/screen3_img12.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img12.png' },
            { label: 'Back', image: '/images/products/screen3_img11.png' },
            { label: 'Left', image: '/images/products/screen3_img13.png' },
            { label: 'Right', image: '/images/products/screen3_img14.png' },
        ],
        ratingBreakdown: { 5: 85, 4: 68, 3: 38, 2: 12, 1: 7 },
    },
    {
        productId: 'sofa-3',
        name: 'L-Shape Sofa',
        description: 'Spacious L-shaped design for corner spaces.',
        category: 'Sofas',
        price: 550,
        oldPrice: 650,
        discount: 15,
        rating: 4.9,
        totalRatings: 8900,
        reviews: 198,
        dimensions: { height: '88 cm', width: '280 cm', depth: '180 cm', weight: '95 kg' },
        colors: ['#5D7EA0', '#D4C4A8', '#1a2632'],
        image: '/images/products/screen3_img13.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img13.png' },
            { label: 'Back', image: '/images/products/screen3_img11.png' },
            { label: 'Left', image: '/images/products/screen3_img12.png' },
            { label: 'Right', image: '/images/products/screen3_img14.png' },
        ],
        ratingBreakdown: { 5: 92, 4: 75, 3: 45, 2: 10, 1: 3 },
    },
    {
        productId: 'sofa-4',
        name: 'Velvet Sofa',
        description: 'Luxurious velvet upholstery for elegance.',
        category: 'Sofas',
        price: 480,
        oldPrice: 600,
        discount: 20,
        rating: 4.6,
        totalRatings: 7200,
        reviews: 165,
        dimensions: { height: '80 cm', width: '200 cm', depth: '90 cm', weight: '58 kg' },
        colors: ['#6B4C7A', '#C4893B', '#1a2632'],
        image: '/images/products/screen3_img14.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img14.png' },
            { label: 'Back', image: '/images/products/screen3_img11.png' },
            { label: 'Left', image: '/images/products/screen3_img12.png' },
            { label: 'Right', image: '/images/products/screen3_img13.png' },
        ],
        ratingBreakdown: { 5: 80, 4: 65, 3: 40, 2: 18, 1: 8 },
    },

    // ============ HANGING CHAIRS ============
    {
        productId: 'hanging-1',
        name: 'Swing Chair',
        description: 'Relaxing swing design for indoor/outdoor use.',
        category: 'Hanging chairs',
        price: 95,
        oldPrice: 120,
        discount: 21,
        rating: 4.5,
        totalRatings: 5600,
        reviews: 125,
        dimensions: { height: '120 cm', width: '80 cm', depth: '80 cm', weight: '15 kg' },
        colors: ['#D4C4A8', '#1a2632'],
        image: '/images/products/screen3_img15.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img15.png' },
            { label: 'Back', image: '/images/products/screen3_img16.png' },
            { label: 'Left', image: '/images/products/screen3_img1.png' },
            { label: 'Right', image: '/images/products/screen3_img2.png' },
        ],
        ratingBreakdown: { 5: 75, 4: 60, 3: 35, 2: 15, 1: 10 },
    },
    {
        productId: 'hanging-2',
        name: 'Hammock Chair',
        description: 'Perfect for patios and outdoor relaxation.',
        category: 'Hanging chairs',
        price: 110,
        oldPrice: 140,
        discount: 21,
        rating: 4.6,
        totalRatings: 4800,
        reviews: 108,
        dimensions: { height: '130 cm', width: '90 cm', depth: '85 cm', weight: '12 kg' },
        colors: ['#8B7355', '#2C5F8D'],
        image: '/images/products/screen3_img16.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img16.png' },
            { label: 'Back', image: '/images/products/screen3_img15.png' },
            { label: 'Left', image: '/images/products/screen3_img1.png' },
            { label: 'Right', image: '/images/products/screen3_img2.png' },
        ],
        ratingBreakdown: { 5: 78, 4: 62, 3: 38, 2: 12, 1: 8 },
    },
    {
        productId: 'hanging-3',
        name: 'Pod Chair',
        description: 'Modern pod design for cozy reading corners.',
        category: 'Hanging chairs',
        price: 150,
        oldPrice: 180,
        discount: 17,
        rating: 4.7,
        totalRatings: 3500,
        reviews: 82,
        dimensions: { height: '140 cm', width: '95 cm', depth: '90 cm', weight: '18 kg' },
        colors: ['#1a2632', '#C4893B'],
        image: '/images/products/screen3_img1.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img1.png' },
            { label: 'Back', image: '/images/products/screen3_img15.png' },
            { label: 'Left', image: '/images/products/screen3_img16.png' },
            { label: 'Right', image: '/images/products/screen3_img2.png' },
        ],
        ratingBreakdown: { 5: 82, 4: 68, 3: 40, 2: 10, 1: 5 },
    },
    {
        productId: 'hanging-4',
        name: 'Basket Chair',
        description: 'Woven basket design with natural aesthetics.',
        category: 'Hanging chairs',
        price: 85,
        oldPrice: 100,
        discount: 15,
        rating: 4.4,
        totalRatings: 2800,
        reviews: 65,
        dimensions: { height: '115 cm', width: '85 cm', depth: '80 cm', weight: '10 kg' },
        colors: ['#D4C4A8', '#8B7355'],
        image: '/images/products/screen3_img2.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img2.png' },
            { label: 'Back', image: '/images/products/screen3_img15.png' },
            { label: 'Left', image: '/images/products/screen3_img16.png' },
            { label: 'Right', image: '/images/products/screen3_img1.png' },
        ],
        ratingBreakdown: { 5: 70, 4: 55, 3: 32, 2: 18, 1: 12 },
    },

    // ============ CABINETS ============
    {
        productId: 'cabinet-1',
        name: 'Storage Cabinet',
        description: 'Multiple shelves for organized storage.',
        category: 'Cabinets',
        price: 180,
        oldPrice: 220,
        discount: 18,
        rating: 4.5,
        totalRatings: 6200,
        reviews: 142,
        dimensions: { height: '180 cm', width: '80 cm', depth: '45 cm', weight: '48 kg' },
        colors: ['#D4C4A8', '#1a2632'],
        image: '/images/products/screen3_img17.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img17.png' },
            { label: 'Back', image: '/images/products/screen3_img3.png' },
            { label: 'Left', image: '/images/products/screen3_img4.png' },
            { label: 'Right', image: '/images/products/screen3_img5.png' },
        ],
        ratingBreakdown: { 5: 76, 4: 62, 3: 38, 2: 14, 1: 8 },
    },
    {
        productId: 'cabinet-2',
        name: 'Display Cabinet',
        description: 'Glass doors to showcase your collection.',
        category: 'Cabinets',
        price: 250,
        oldPrice: 300,
        discount: 17,
        rating: 4.6,
        totalRatings: 4800,
        reviews: 115,
        dimensions: { height: '190 cm', width: '100 cm', depth: '40 cm', weight: '55 kg' },
        colors: ['#8B7355', '#1a2632'],
        image: '/images/products/screen3_img3.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img3.png' },
            { label: 'Back', image: '/images/products/screen3_img17.png' },
            { label: 'Left', image: '/images/products/screen3_img4.png' },
            { label: 'Right', image: '/images/products/screen3_img5.png' },
        ],
        ratingBreakdown: { 5: 80, 4: 65, 3: 35, 2: 12, 1: 6 },
    },
    {
        productId: 'cabinet-3',
        name: 'TV Cabinet',
        description: 'Sleek media storage for your entertainment setup.',
        category: 'Cabinets',
        price: 200,
        oldPrice: 260,
        discount: 23,
        rating: 4.7,
        totalRatings: 5500,
        reviews: 128,
        dimensions: { height: '55 cm', width: '160 cm', depth: '45 cm', weight: '38 kg' },
        colors: ['#1a2632', '#C4893B'],
        image: '/images/products/screen3_img4.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img4.png' },
            { label: 'Back', image: '/images/products/screen3_img17.png' },
            { label: 'Left', image: '/images/products/screen3_img3.png' },
            { label: 'Right', image: '/images/products/screen3_img5.png' },
        ],
        ratingBreakdown: { 5: 84, 4: 70, 3: 38, 2: 10, 1: 5 },
    },
    {
        productId: 'cabinet-4',
        name: 'File Cabinet',
        description: 'Office organizer with locking drawers.',
        category: 'Cabinets',
        price: 120,
        oldPrice: 150,
        discount: 20,
        rating: 4.3,
        totalRatings: 3200,
        reviews: 78,
        dimensions: { height: '70 cm', width: '40 cm', depth: '50 cm', weight: '25 kg' },
        colors: ['#5D7EA0', '#1a2632'],
        image: '/images/products/screen3_img5.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img5.png' },
            { label: 'Back', image: '/images/products/screen3_img17.png' },
            { label: 'Left', image: '/images/products/screen3_img3.png' },
            { label: 'Right', image: '/images/products/screen3_img4.png' },
        ],
        ratingBreakdown: { 5: 68, 4: 55, 3: 40, 2: 20, 1: 12 },
    },

    // ============ LAMPS ============
    {
        productId: 'lamp-1',
        name: 'Floor Lamp',
        description: 'Adjustable height for reading and ambiance.',
        category: 'Lamps',
        price: 65,
        oldPrice: 85,
        discount: 24,
        rating: 4.5,
        totalRatings: 7800,
        reviews: 165,
        dimensions: { height: '160 cm', width: '35 cm', depth: '35 cm', weight: '8 kg' },
        colors: ['#FFB800', '#1a2632'],
        image: '/images/products/screen3_img6.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img6.png' },
            { label: 'Back', image: '/images/products/screen3_img7.png' },
            { label: 'Left', image: '/images/products/screen3_img8.png' },
            { label: 'Right', image: '/images/products/screen3_img9.png' },
        ],
        ratingBreakdown: { 5: 78, 4: 62, 3: 35, 2: 15, 1: 8 },
    },
    {
        productId: 'lamp-2',
        name: 'Table Lamp',
        description: 'Bedside lighting with soft glow.',
        category: 'Lamps',
        price: 35,
        oldPrice: 45,
        discount: 22,
        rating: 4.4,
        totalRatings: 9200,
        reviews: 198,
        dimensions: { height: '45 cm', width: '25 cm', depth: '25 cm', weight: '3 kg' },
        colors: ['#D4C4A8', '#2C5F8D'],
        image: '/images/products/screen3_img7.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img7.png' },
            { label: 'Back', image: '/images/products/screen3_img6.png' },
            { label: 'Left', image: '/images/products/screen3_img8.png' },
            { label: 'Right', image: '/images/products/screen3_img9.png' },
        ],
        ratingBreakdown: { 5: 72, 4: 58, 3: 38, 2: 18, 1: 10 },
    },
    {
        productId: 'lamp-3',
        name: 'Desk Lamp',
        description: 'Focused lighting for study and work.',
        category: 'Lamps',
        price: 40,
        oldPrice: 55,
        discount: 27,
        rating: 4.6,
        totalRatings: 11500,
        reviews: 245,
        dimensions: { height: '50 cm', width: '20 cm', depth: '30 cm', weight: '4 kg' },
        colors: ['#1a2632', '#C4893B'],
        image: '/images/products/screen3_img8.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img8.png' },
            { label: 'Back', image: '/images/products/screen3_img6.png' },
            { label: 'Left', image: '/images/products/screen3_img7.png' },
            { label: 'Right', image: '/images/products/screen3_img9.png' },
        ],
        ratingBreakdown: { 5: 82, 4: 68, 3: 32, 2: 12, 1: 6 },
    },
    {
        productId: 'lamp-4',
        name: 'Wall Lamp',
        description: 'Space-saving wall-mounted design.',
        category: 'Lamps',
        price: 50,
        oldPrice: 70,
        discount: 29,
        rating: 4.5,
        totalRatings: 5600,
        reviews: 125,
        dimensions: { height: '30 cm', width: '20 cm', depth: '25 cm', weight: '2 kg' },
        colors: ['#8B7355', '#FFB800'],
        image: '/images/products/screen3_img9.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img9.png' },
            { label: 'Back', image: '/images/products/screen3_img6.png' },
            { label: 'Left', image: '/images/products/screen3_img7.png' },
            { label: 'Right', image: '/images/products/screen3_img8.png' },
        ],
        ratingBreakdown: { 5: 76, 4: 60, 3: 36, 2: 16, 1: 9 },
    },

    // ============ CUPBOARDS ============
    {
        productId: 'cupboard-1',
        name: 'Kitchen Cupboard',
        description: 'Storage solution for kitchen essentials.',
        category: 'Cupboards',
        price: 220,
        oldPrice: 280,
        discount: 21,
        rating: 4.5,
        totalRatings: 4800,
        reviews: 108,
        dimensions: { height: '200 cm', width: '100 cm', depth: '50 cm', weight: '65 kg' },
        colors: ['#D4C4A8', '#1a2632'],
        image: '/images/products/screen3_img10.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img10.png' },
            { label: 'Back', image: '/images/products/screen3_img11.png' },
            { label: 'Left', image: '/images/products/screen3_img12.png' },
            { label: 'Right', image: '/images/products/screen3_img13.png' },
        ],
        ratingBreakdown: { 5: 74, 4: 60, 3: 38, 2: 16, 1: 10 },
    },
    {
        productId: 'cupboard-2',
        name: 'Bedroom Cupboard',
        description: 'Wardrobe-style storage for clothes.',
        category: 'Cupboards',
        price: 300,
        oldPrice: 380,
        discount: 21,
        rating: 4.7,
        totalRatings: 6200,
        reviews: 142,
        dimensions: { height: '220 cm', width: '150 cm', depth: '60 cm', weight: '85 kg' },
        colors: ['#8B7355', '#1a2632'],
        image: '/images/products/screen3_img11.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img11.png' },
            { label: 'Back', image: '/images/products/screen3_img10.png' },
            { label: 'Left', image: '/images/products/screen3_img12.png' },
            { label: 'Right', image: '/images/products/screen3_img13.png' },
        ],
        ratingBreakdown: { 5: 82, 4: 68, 3: 35, 2: 12, 1: 5 },
    },
    {
        productId: 'cupboard-3',
        name: 'Corner Cupboard',
        description: 'Space-efficient design for corners.',
        category: 'Cupboards',
        price: 160,
        oldPrice: 200,
        discount: 20,
        rating: 4.4,
        totalRatings: 3500,
        reviews: 85,
        dimensions: { height: '180 cm', width: '80 cm', depth: '80 cm', weight: '45 kg' },
        colors: ['#C4893B', '#1a2632'],
        image: '/images/products/screen3_img12.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img12.png' },
            { label: 'Back', image: '/images/products/screen3_img10.png' },
            { label: 'Left', image: '/images/products/screen3_img11.png' },
            { label: 'Right', image: '/images/products/screen3_img13.png' },
        ],
        ratingBreakdown: { 5: 70, 4: 55, 3: 40, 2: 18, 1: 12 },
    },
    {
        productId: 'cupboard-4',
        name: 'Tall Cupboard',
        description: 'Extra storage with vertical design.',
        category: 'Cupboards',
        price: 240,
        oldPrice: 300,
        discount: 20,
        rating: 4.6,
        totalRatings: 4200,
        reviews: 98,
        dimensions: { height: '240 cm', width: '60 cm', depth: '45 cm', weight: '55 kg' },
        colors: ['#5D7EA0', '#D4C4A8'],
        image: '/images/products/screen3_img13.png',
        productViews: [
            { label: 'Front', image: '/images/products/screen3_img13.png' },
            { label: 'Back', image: '/images/products/screen3_img10.png' },
            { label: 'Left', image: '/images/products/screen3_img11.png' },
            { label: 'Right', image: '/images/products/screen3_img12.png' },
        ],
        ratingBreakdown: { 5: 78, 4: 65, 3: 38, 2: 14, 1: 8 },
    },
];

// =====================================================================
// ============ USERS & ORDERS SEED DATA (RFM / K-Means) ==============
// =====================================================================
//
// 20 users split into 3 behavioral groups for clean K-Means clustering:
//   Group 1 — VIP / Loyal       (users 0-4):   High F, High M, Low R
//   Group 2 — Dormant / At-Risk (users 5-11):  Mid F, Mid M, High R
//   Group 3 — Casual / Low      (users 12-19): Low F, Low M, Mixed R
//
// Orders are generated deterministically via a seeded PRNG so the
// dataset is identical every time the server starts or seeds.
// =====================================================================

// ============ Deterministic PRNG (Lehmer / Park-Miller) ============
function _seededRNG(seed) {
    let s = seed % 2147483647;
    if (s <= 0) s += 2147483646;
    return function () {
        s = (s * 16807) % 2147483647;
        return (s - 1) / 2147483646;
    };
}

const _rng = _seededRNG(2026);
const _randInt = (min, max) => Math.floor(_rng() * (max - min + 1)) + min;
const _randFloat = (min, max) => +(_rng() * (max - min) + min).toFixed(2);
const _randItem = (arr) => arr[Math.floor(_rng() * arr.length)];
const _randDate = (start, end) =>
    new Date(start.getTime() + Math.floor(_rng() * (end.getTime() - start.getTime())));

// ============ 20 USERS ============

const USERS_SEED = [
    // ====== GROUP 1: VIP / Loyal (index 0-4) ======
    // 🔑 Password mặc định cho tất cả users: "fuzzy123"
    {
        name: 'Nguyễn Minh Anh',
        email: 'minhanh.nguyen@gmail.com',
        password: 'fuzzy123',
        phone: '0901234567',
        address: { street: '12 Nguyễn Huệ', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },
    {
        name: 'Trần Đức Huy',
        email: 'duchuy.tran@gmail.com',
        password: 'fuzzy123',
        phone: '0912345678',
        address: { street: '45 Lê Lợi', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },
    {
        name: 'Lê Thị Hồng Nhung',
        email: 'hongnhung.le@gmail.com',
        password: 'fuzzy123',
        phone: '0923456789',
        address: { street: '78 Hai Bà Trưng', city: 'Hà Nội', state: 'HN', zipCode: '100000' },
    },
    {
        name: 'Phạm Quốc Bảo',
        email: 'quocbao.pham@gmail.com',
        password: 'fuzzy123',
        phone: '0934567890',
        address: { street: '23 Trần Phú', city: 'Đà Nẵng', state: 'DN', zipCode: '550000' },
    },
    {
        name: 'Hoàng Thùy Linh',
        email: 'thuylinh.hoang@gmail.com',
        password: 'fuzzy123',
        phone: '0945678901',
        address: { street: '56 Pasteur', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },

    // ====== GROUP 2: Dormant / At-Risk (index 5-11) ======
    {
        name: 'Vũ Thanh Tùng',
        email: 'thanhtung.vu@gmail.com',
        password: 'fuzzy123',
        phone: '0956789012',
        address: { street: '89 Bà Triệu', city: 'Hà Nội', state: 'HN', zipCode: '100000' },
    },
    {
        name: 'Đặng Thị Mai',
        email: 'thimai.dang@gmail.com',
        password: 'fuzzy123',
        phone: '0967890123',
        address: { street: '34 Nguyễn Trãi', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },
    {
        name: 'Bùi Văn Khoa',
        email: 'vankhoa.bui@gmail.com',
        password: 'fuzzy123',
        phone: '0978901234',
        address: { street: '67 Lý Thường Kiệt', city: 'Huế', state: 'TH', zipCode: '530000' },
    },
    {
        name: 'Ngô Phương Thảo',
        email: 'phuongthao.ngo@gmail.com',
        password: 'fuzzy123',
        phone: '0989012345',
        address: { street: '12 Trường Chinh', city: 'Hà Nội', state: 'HN', zipCode: '100000' },
    },
    {
        name: 'Lý Hoàng Nam',
        email: 'hoangnam.ly@gmail.com',
        password: 'fuzzy123',
        phone: '0990123456',
        address: { street: '90 Lê Duẩn', city: 'Đà Nẵng', state: 'DN', zipCode: '550000' },
    },
    {
        name: 'Trịnh Khánh Linh',
        email: 'khanhlinh.trinh@gmail.com',
        password: 'fuzzy123',
        phone: '0901122334',
        address: { street: '45 Nguyễn Du', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },
    {
        name: 'Dương Minh Tuấn',
        email: 'minhtuan.duong@gmail.com',
        password: 'fuzzy123',
        phone: '0912233445',
        address: { street: '23 Hoàng Hoa Thám', city: 'Hà Nội', state: 'HN', zipCode: '100000' },
    },

    // ====== GROUP 3: Casual / Low-value (index 12-19) ======
    {
        name: 'Phan Thị Lan',
        email: 'thilan.phan@gmail.com',
        password: 'fuzzy123',
        phone: '0923344556',
        address: { street: '78 Điện Biên Phủ', city: 'Cần Thơ', state: 'CT', zipCode: '900000' },
    },
    {
        name: 'Cao Bá Quát',
        email: 'baquat.cao@gmail.com',
        password: 'fuzzy123',
        phone: '0934455667',
        address: { street: '56 Hùng Vương', city: 'Hải Phòng', state: 'HP', zipCode: '180000' },
    },
    {
        name: 'Mai Thị Hạnh',
        email: 'thihanh.mai@gmail.com',
        password: 'fuzzy123',
        phone: '0945566778',
        address: { street: '34 Nguyễn Văn Cừ', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },
    {
        name: 'Tô Quang Vinh',
        email: 'quangvinh.to@gmail.com',
        password: 'fuzzy123',
        phone: '0956677889',
        address: { street: '12 Lê Hồng Phong', city: 'Nha Trang', state: 'KH', zipCode: '650000' },
    },
    {
        name: 'Hà Thế Anh',
        email: 'theanh.ha@gmail.com',
        password: 'fuzzy123',
        phone: '0967788990',
        address: { street: '89 Trần Hưng Đạo', city: 'Đà Lạt', state: 'LD', zipCode: '670000' },
    },
    {
        name: 'Châu Ngọc Diệp',
        email: 'ngocdiep.chau@gmail.com',
        password: 'fuzzy123',
        phone: '0978899001',
        address: { street: '45 Phan Đình Phùng', city: 'Huế', state: 'TH', zipCode: '530000' },
    },
    {
        name: 'Lâm Hữu Phước',
        email: 'huuphuoc.lam@gmail.com',
        password: 'fuzzy123',
        phone: '0989900112',
        address: { street: '67 Võ Văn Tần', city: 'Hồ Chí Minh', state: 'HCM', zipCode: '700000' },
    },
    {
        name: 'Đinh Công Sơn',
        email: 'congson.dinh@gmail.com',
        password: 'fuzzy123',
        phone: '0990011223',
        address: { street: '23 Nguyễn Thái Học', city: 'Quy Nhơn', state: 'BD', zipCode: '590000' },
    },
];

// ============ ORDER GENERATION ENGINE ============

const _REF_DATE   = new Date('2026-04-17T00:00:00');
const _YEAR_AGO   = new Date('2025-04-17T00:00:00');

// Build product lookup tables by price tier
const _productPool = PRODUCTS_SEED.map(p => ({
    productId: p.productId,
    productName: p.name,
    price: p.price,
}));
const _highValueProducts = _productPool.filter(p => p.price >= 150);
const _midValueProducts  = _productPool.filter(p => p.price >= 50 && p.price < 250);
const _lowValueProducts  = _productPool.filter(p => p.price < 80);
const _PAYMENTS = ['Credit Card', 'PayPal', 'Bank Transfer', 'Cash on Delivery'];

function _makeItems(pool, minQty, maxQty, minItems, maxItems) {
    const n = _randInt(minItems, maxItems);
    const items = [];
    for (let i = 0; i < n; i++) {
        const prod = _randItem(pool);
        items.push({
            productId: prod.productId,
            productName: prod.productName,
            quantity: _randInt(minQty, maxQty),
            price: prod.price,
        });
    }
    return items;
}

function _itemsTotal(items) {
    return +items.reduce((s, it) => s + it.price * it.quantity, 0).toFixed(2);
}

function _generateAllOrders() {
    const orders = [];
    let counter = 1;

    // ────────────────────────────────────────────────
    // GROUP 1 — VIP / Loyal  (users 0-4)
    //   ~35-45 orders each, high-value items, recent
    // ────────────────────────────────────────────────
    const vipOrderCounts = [38, 42, 36, 45, 40]; // total ≈ 201
    for (let u = 0; u < 5; u++) {
        const numOrders = vipOrderCounts[u];
        for (let i = 0; i < numOrders; i++) {
            let orderDate;
            if (i >= numOrders - 2) {
                // Last 2 orders: within the most recent 14 days
                orderDate = _randDate(
                    new Date('2026-04-03T00:00:00'),
                    new Date('2026-04-16T23:59:59')
                );
            } else {
                // Spread across the rest of the year
                orderDate = _randDate(_YEAR_AGO, new Date('2026-04-02T23:59:59'));
            }

            const items = _makeItems(
                _rng() > 0.25 ? _highValueProducts : _midValueProducts,
                1, 3,  // quantity per item
                2, 4   // number of distinct items
            );

            orders.push({
                userIndex: u,
                orderDate,
                totalAmount: _itemsTotal(items),
                status: 'Completed',
                items,
                paymentMethod: _randItem(_PAYMENTS),
                orderNumber: `ORD-${String(counter++).padStart(5, '0')}`,
            });
        }
    }

    // ────────────────────────────────────────────────
    // GROUP 2 — Dormant / At-Risk  (users 5-11)
    //   ~18-26 orders each, medium-value items
    //   ALL orders before Dec 2025 → Recency = 4-6 months
    // ────────────────────────────────────────────────
    const dormantOrderCounts = [22, 25, 18, 20, 26, 24, 21]; // total ≈ 156
    const dormantLastStart = new Date('2025-10-01T00:00:00');
    const dormantLastEnd   = new Date('2025-12-15T23:59:59');

    for (let u = 5; u < 12; u++) {
        const numOrders = dormantOrderCounts[u - 5];
        for (let i = 0; i < numOrders; i++) {
            let orderDate;
            if (i >= numOrders - 1) {
                // The very last order: Oct–Dec 2025 (4-6 months ago)
                orderDate = _randDate(dormantLastStart, dormantLastEnd);
            } else {
                // Earlier orders: spread from Apr 2025 to Sep 2025
                orderDate = _randDate(_YEAR_AGO, new Date('2025-09-30T23:59:59'));
            }

            const items = _makeItems(
                _midValueProducts,
                1, 2,  // quantity per item
                1, 3   // number of distinct items
            );

            orders.push({
                userIndex: u,
                orderDate,
                totalAmount: _itemsTotal(items),
                status: 'Completed',
                items,
                paymentMethod: _randItem(_PAYMENTS),
                orderNumber: `ORD-${String(counter++).padStart(5, '0')}`,
            });
        }
    }

    // ────────────────────────────────────────────────
    // GROUP 3 — Casual / Low-value  (users 12-19)
    //   1-3 orders each, low-value items, single item
    // ────────────────────────────────────────────────
    const casualOrderCounts = [2, 1, 3, 2, 1, 2, 3, 1]; // total ≈ 15
    for (let u = 12; u < 20; u++) {
        const numOrders = casualOrderCounts[u - 12];
        for (let i = 0; i < numOrders; i++) {
            const orderDate = _randDate(_YEAR_AGO, _REF_DATE);

            const items = _makeItems(
                _lowValueProducts,
                1, 1,  // quantity always 1
                1, 1   // always 1 item per order
            );

            orders.push({
                userIndex: u,
                orderDate,
                totalAmount: _itemsTotal(items),
                status: _rng() > 0.15 ? 'Completed' : 'Cancelled',
                items,
                paymentMethod: _randItem(_PAYMENTS),
                orderNumber: `ORD-${String(counter++).padStart(5, '0')}`,
            });
        }
    }

    // Sort chronologically
    orders.sort((a, b) => a.orderDate.getTime() - b.orderDate.getTime());
    return orders;
}

const ORDERS_SEED = _generateAllOrders();

// ============ SUMMARY (logged on import for verification) ============
// Uncomment the line below to verify distribution when debugging:
// console.log(`📊 Seed Stats: ${USERS_SEED.length} users, ${ORDERS_SEED.length} orders (VIP≈201, Dormant≈156, Casual≈15)`);

module.exports = { CATEGORIES_SEED, PRODUCTS_SEED, USERS_SEED, ORDERS_SEED };
